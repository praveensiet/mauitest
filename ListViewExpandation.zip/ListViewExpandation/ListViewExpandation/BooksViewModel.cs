﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ListViewExpandation
{

    public class BooksViewModel : BaseViewModel
    {
        public List<Books> booksList { get; set; }

        public ObservableCollection<GroupedBooks> groupedBooksList { get; set; }


        public BooksViewModel()
        {
            booksList = new List<Books>();
            groupedBooksList = new ObservableCollection<GroupedBooks>();

            booksList.AddRange(new List<Books>
            {
                new Books("Gretchen Rubin","The Happiness Project","2010","Gretchen Rubin, a writer known for her work on habits and happiness, decided to test out different philosophies about happiness throughout a year. Each month she focused on a different aspect of happiness, such as money, relationships, and energy. Rubin documented her experiences in this book"),
                new Books("Ramit Sethi","I Will Teach You To Be Rich","2009","This book by personal finance expert Ramit Sethi provides a no-nonsense approach to personal finance. Sethi breaks down complex financial concepts into easy-to-understand steps and offers actionable advice on topics such as budgeting, saving, investing, and paying off debt"),
                new Books("David Bach","The Automatic Millionaire","2009","The Automatic Millionaire,  focuses on the concept of automating your finances to build wealth over time. Bach argues that by setting up automatic systems for saving and investing, you can take the guesswork out of financial planning and achieve your financial goals on autopilot."),
                new Books("Paramahansa Yogananda","Autobiography of a Yogi","1946","This autobiography details Yogananda's life journey, his spiritual experiences under his guru Sri Yukteswar, and his introduction of Kriya Yoga meditation practices to the West. It remains a foundational text for many seeking self-realization and exploring Eastern spirituality."),
                new Books("Héctor García,Francesc Miralles","Ikigai: The Japanese Secret to a Long and Happy Life","2016","This book explores the Japanese concept of Ikigai, which translates to \"reason for being\" or \"life purpose\".  The book explores the secrets to longevity and happiness in the Japanese village of Okinawa, known for having a high concentration of centenarians."),
                new Books("Malcolm Gladwell ","Outliers: The Story of Success","2010","Malcolm Gladwell, a bestselling author known for his exploration of the factors behind success, examines the idea of outliers in this book. Outliers are people who achieve far more than their peers."),
                new Books("Swami Prabhananda","Vivekananda Reader","1946","This compilation of Swami Vivekananda's lectures and writings presents his core teachings on Vedanta philosophy, yoga, and the importance of social service. Vivekananda was a key figure in introducing Hinduism to the West and promoting interfaith dialogue"),
                new Books("Rick Warren","The Purpose Driven Life: What on Earth Am I Here For?(Updated)","2016","This book by Rick Warren, a prominent pastor and author, delves into the concept of finding your purpose in life from a Christian perspective. It explores questions like why we are here, what difference we can make, and how to live a life that matters."),
            });
            OnPropertyChanged("booksList");
            LoadGroupedData();
        }

        public void LoadGroupedData()
        {
            groupedBooksList = new ObservableCollection<GroupedBooks>();

            //Grouping List based on Year
            var itemDict = (booksList.OrderBy(x => x.PublishedDate)).GroupBy(y => y.PublishedDate).ToDictionary(o => o.Key, o => o.ToList());

            foreach (KeyValuePair<string, List<Books>> item in itemDict)
            {
                var groupKey = new GroupedBooks() { ReleasedDate = item.Key };

                foreach (var val in item.Value)
                {
                    groupKey.Add(val);
                }
                groupedBooksList.Add(groupKey);
            }
            OnPropertyChanged("groupedBooksList");
        }
    }

    public class BindableBase : INotifyPropertyChanged
    {
        
        protected virtual bool SetProperty<T>(
            ref T backingStore, T value,
            [CallerMemberName] string propertyName = "",
            Action? onChanged = null,
            Func<T, T, bool>? validateValue = null)
        {
            //if value didn't change
            if (EqualityComparer<T>.Default.Equals(backingStore, value))
                return false;

            //if value changed but didn't validate
            if (validateValue != null && !validateValue(backingStore, value))
                return false;

            backingStore = value;
            onChanged?.Invoke();
            OnPropertyChanged(propertyName);
            return true;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "") =>
         PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public class BaseViewModel : BindableBase
    {

    }

    public class Books : BindableBase
    {
        public string Author { get; set; }
        public string BookName { get; set; }
        public string PublishedDate { get; set; }
        public string ShortDetail { get; set; }

        private bool _toggleView = false;
        public bool ToggleView
        {
            get => _toggleView;
            set { SetProperty(ref _toggleView, value); }
        }

        private bool _isExpanded = false;
        public bool IsExpanded
        {
            get => _isExpanded;
            set { SetProperty(ref _isExpanded, value); }
        }

        private bool _isMenuVisible = true;
        public bool IsMenuVisible
        {
            get => _isMenuVisible;
            set { SetProperty(ref _isMenuVisible, value); }
        }

        public Books(string author = null, string book = null, string date = null, string detail = null)
        {
            Author = author;
            BookName = book;
            PublishedDate = date;
            ShortDetail = detail;
        }
    }

    public class GroupedBooks : List<Books>
    {
        public string ReleasedDate { get; set; }

    }
}

