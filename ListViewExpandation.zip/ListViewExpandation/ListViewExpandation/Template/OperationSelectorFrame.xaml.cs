﻿namespace ListViewExpandation.Template;

public partial class OperationSelectorFrame : Grid
{

    public OperationSelectorFrame()
	{
		InitializeComponent();
	}

    //OpenTapped
    void TapGestureRecognizer_Tapped(System.Object sender, Microsoft.Maui.Controls.TappedEventArgs e)
    {
        TapGrid.IsVisible = false;
        commentGrid.IsVisible = true;

        var elem = (sender as View).Parent.Parent.Parent.Parent.Parent;
        (elem as ViewCell).ForceUpdateSize();
    }

    void TapGestureRecognizer_Tapped_1(System.Object sender, Microsoft.Maui.Controls.TappedEventArgs e)
    {
        TapGrid.IsVisible = true;
        commentGrid.IsVisible = false;

        var elem = (sender as View).Parent.Parent.Parent.Parent.Parent;
        (elem as ViewCell).ForceUpdateSize();
    }
}
