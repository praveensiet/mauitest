﻿namespace ListViewExpandation.Template;

public partial class CardTemplate : Grid
{
	public CardTemplate()
	{
		InitializeComponent();
	}
}
