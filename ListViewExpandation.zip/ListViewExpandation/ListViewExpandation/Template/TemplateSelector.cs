﻿using System;
namespace ListViewExpandation.Template
{
	public class TemplateSelector : DataTemplateSelector
	{
        public DataTemplate CardTemplate { get; set; }
        public DataTemplate DetailTemplate { get; set; }

        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            try
            {
                var bkmdl = item as Books;
                Books bks = new Books(bkmdl.Author, bkmdl.BookName, bkmdl.PublishedDate, bkmdl.ShortDetail);
                return bkmdl.ToggleView == true ? CardTemplate : DetailTemplate;
            }
            catch (Exception ex)
            {
                ex.ToString();
                return CardTemplate;
            }
        }
    }
}

