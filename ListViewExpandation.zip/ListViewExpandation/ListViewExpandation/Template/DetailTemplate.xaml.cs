﻿namespace ListViewExpandation.Template;

public partial class DetailTemplate : Grid
{
	public DetailTemplate()
	{
		InitializeComponent();
	}

    void TapGestureRecognizer_Tapped(System.Object sender, Microsoft.Maui.Controls.TappedEventArgs e)
    {
		var elem = ((sender as Label).Parent.Parent as Grid);
    }
}
