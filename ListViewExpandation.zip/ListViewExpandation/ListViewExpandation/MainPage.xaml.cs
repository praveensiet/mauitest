﻿namespace ListViewExpandation;

public partial class MainPage : ContentPage
{
	public BooksViewModel ViewModel { get; set; }

    public MainPage()
	{
		InitializeComponent();
        ViewModel = new BooksViewModel();
        BindingContext = ViewModel;
    }


    void TapGestureRecognizer_Tapped_1(System.Object sender, Microsoft.Maui.Controls.TappedEventArgs e)
    {
        string imgSource = (sender as Image).Source.ToString();
        if (imgSource.Substring(6) == "list_br")
        {
            ViewModel.groupedBooksList.ForEach((obj) =>
            {
                obj.ForEach((obj1) =>
                {
                    obj1.ToggleView = true;
                });
            });
            OnPropertyChanged("ToggleView");
            OnPropertyChanged("groupedBooksList");
            //ViewModel.groupedBooksList.All(x => x.ToList().ForEach(y => y.ToggleView = true));
            //Where(x => x.ToggleView = true);
            (sender as Image).Source = "close";
            ViewModel.LoadGroupedData();
        }
        else
        {
            ViewModel.groupedBooksList.ForEach((obj) =>
            {
                obj.ForEach((obj1) =>
                {
                    obj1.ToggleView = false;
                });
            });
            OnPropertyChanged("ToggleView");
            OnPropertyChanged("groupedBooksList");
            //ViewModel.booksList.ForEach(x => x.ToggleView = false);
            (sender as Image).Source = "list_br";
            ViewModel.LoadGroupedData();
        }
    }

}


public static class EnumerableExtensions
{
    public static void ForEach<T>(this IEnumerable<T> enumeration, Action<T> action)
    {
        foreach (T item in enumeration)
        {
            action(item);
        }
    }
}


